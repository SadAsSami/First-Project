package Entity;
import java.lang.*;
import java.io.*;
import javax.swing.*;
public class Customer
{
    private String s1, s2, s3, s4, s5, s6, s7;

    private File file;
    private FileWriter fileWriter;

    public Customer(){}
    public Customer(String s1, String s2, String s3, String s4, String s5, String s6, String s7)
    {
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
        this.s4 = s4;
        this.s5 = s5;
        this.s6 = s6;
        this.s7 = s7;
    }

    public void insertInfo()
    {
        try
        {
            file = new File("./Data/CustomerData.txt");

            if(!file.exists())
            {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }

            fileWriter = new FileWriter(file, true);
            fileWriter.write("-----------------------------------"+"\n");
            fileWriter.write("Name: "+s1+"\n");
            fileWriter.write("Number: "+s2+"\n");
            fileWriter.write("Reference Code: "+s3+"\n");
            fileWriter.write("Model: "+s4+"\n");
            fileWriter.write("Additional Items: "+s5+"\n");
            fileWriter.write("Payment Method: "+s6+"\n");
            fileWriter.write("Feedback: "+s7+"\n");
            fileWriter.write("-----------------------------------"+"\n");

            fileWriter.flush();
            fileWriter.close();
        }

        catch(IOException io)
        {
            io.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occours");
        }
    }
}