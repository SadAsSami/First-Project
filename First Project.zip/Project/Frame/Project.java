package Frame;
import Entity.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
public class Project extends JFrame implements ActionListener,MouseListener
{
    private JPanel panel;
    private JLabel label1, label2, label3,label4, label5, label6, label7, label8, label9, label10;
    private ImageIcon img;
    private JTextField tf, tf1;
    private JPasswordField pf;
    private JComboBox cb;
    private JCheckBox jc1, jc2, jc3;
    private JRadioButton rb1, rb2, rb3;
    private ButtonGroup bg;
    private JButton jb, jb1, jb3;
    private JTextArea ta;
	private JTable tb;
    private Color c1;
    private Font f1,f2;
    private DefaultTableModel model;



    public Project()
    {
        super("Watch Shop Management System");
        super.setBounds(500, 200, 1000, 700);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        c1 = new Color(240,250,190);
        panel.setBackground(c1);
		
		f2 = new Font("Cambria", Font.BOLD, 18);

        img = new ImageIcon("Picture\\LOGO4.jpg");
        label1 = new JLabel(img);
        label1.setBounds(0, 0, 100, 90);
        panel.add(label1);

        label7 = new JLabel("  SR WATCH WORLD");
        label7.setBounds(100, 0, 900, 90);
        f1 = new Font("Algerian", Font.BOLD, 30);
        label7.setFont(f1);
        label7.setBackground(Color.WHITE);
        label7.setOpaque(true);
        panel.add(label7);

        label2 = new JLabel("Customer Info");
        label2.setBounds(350, 80, 270, 50);
        f1 = new Font("Britannic Bold", Font.BOLD, 25);
        label2.setFont(f1);
		label2.addMouseListener(this);
        panel.add(label2);
		
		label8 = new JLabel("Customer name -");
		label8.setBounds(10,140,150,50);
		label8.setFont(f2);
		panel.add(label8);
		
		tf1 = new JTextField();
		tf1.setBounds(170,150,150,30);
        tf1.setFont(f2);
		panel.add(tf1);

        label9 = new JLabel("Phone number -");
        label9.setBounds(10, 190, 250, 50);
		label9.setFont(f2);
        panel.add(label9);

        tf = new JTextField();
        tf.setBounds(170, 200, 130, 30);
        tf.setFont(f2);
        panel.add(tf);

        label3 = new JLabel("Reference code -");
        label3.setBounds(10, 240, 200, 50);
		label3.setFont(f2);
        panel.add(label3);

        pf = new JPasswordField();
        pf.setBounds(170, 250, 90, 30);
        pf.setEchoChar('#');
        pf.setFont(f2);
        panel.add(pf);

        jb3 = new JButton("SHOW");
        jb3. setBounds(290, 250, 110, 30);
		jb3.setFont(f2);
		jb3.setBackground(Color.GREEN);
        jb3.addActionListener(this);
        panel.add(jb3);

        label4 = new JLabel("Watch model -");
        label4.setBounds(10, 290, 200, 50);
		label4.setFont(f2);
        panel.add(label4);

        String items[] = new String[] {" ","ROLEX", "NAVIFORCE", "OTHERS"};
        cb = new JComboBox(items);
        cb.setBounds(170, 300, 130, 30);
		//cb.setForeground(Color.BLUE);
        cb.setFont(f2);
        panel.add(cb);

        label5 = new JLabel("Additional items -");
        label5.setBounds(10, 410, 155, 50);
		label5.setFont(f2);
		label5.addMouseListener(this);
        panel.add(label5);

        jc1 = new JCheckBox("Watch box");
        jc1.setBounds(170, 420, 150, 30);
		jc1.setBackground(c1);
        jc1.setFont(f2);
        panel.add(jc1);

        jc2 = new JCheckBox("Watch bag");
        jc2.setBounds(170, 450, 150, 30);
		jc2.setBackground(c1);
        jc2.setFont(f2);
        panel.add(jc2);

        jc3 = new JCheckBox("Gifts");
        jc3.setBounds(170, 480, 150, 30);
		jc3.setBackground(c1);
        jc3.setFont(f2);
        panel.add(jc3);

        label6 = new JLabel("Payment method -");
        label6.setBounds(10, 500, 190, 50);
		label6.setFont(f2);
        panel.add(label6);

        rb1 = new JRadioButton("Cash");
        rb1.setBounds(170, 510, 70, 30);
		rb1.setBackground(c1);
        rb1.setFont(f2);
        panel.add(rb1);

        rb2 = new JRadioButton("Card");
        rb2.setBounds(240, 510, 70, 30);
		rb2.setBackground(c1);
        rb2.setFont(f2);
        panel.add(rb2);

        rb3 = new JRadioButton("Online pay");
        rb3.setBounds(310, 510, 120, 30);
		rb3.setBackground(c1);
        rb3.setFont(f2);
        panel.add(rb3);

        bg = new ButtonGroup();
        bg.add(rb1);
        bg.add(rb2);
        bg.add(rb3);
		
		label10 = new JLabel("Customer Feedback -");
		label10.setBounds(600,160,190,30);
		label10.setFont(f2);
		panel.add(label10);

        ta = new JTextArea();
        ta.setBounds(600, 190, 300, 100);
        ta.setFont(f2);
        panel.add(ta);


        jb = new JButton("DONE");
        jb.setBounds(300, 590, 100, 40);
		jb.setFont(f2);
		jb.setBackground(Color.GREEN);
		jb.addMouseListener(this);
        jb.addActionListener(this);
        panel.add(jb);
		
		jb1 = new JButton("EXIT");
        jb1. setBounds(550, 590, 100, 40);
		jb1.setFont(f2);
		jb1.setBackground(Color.RED);
		jb1.addActionListener(this);
        panel.add(jb1);
		
		
       
		tb = new JTable();
        model = new DefaultTableModel(new Object[]{"Customer Data"}, 0);
        tb.setModel(model);
        JScrollPane sp = new JScrollPane(tb);
        sp.setBounds(600, 350, 300, 190);
        //tb.setFont(f2);
        panel.add(sp);
       

        super.add(panel);
    }
	
	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource() == jb1)
			{
				System.exit(0);
			}
            else if(ae.getSource()== jb3)
            {
                pf.setEchoChar((char)0);
                jb3.setText("SHOWED");
                //jb3.setBackground(Color.GREEN);
                //jb3.setForeground(Color.WHITE);
            }
            else if(ae.getSource()== jb)
            {
                String s1,s2,s3,s4,s5,s6,s7;

                s1= tf1.getText();
                s2= tf.getText();
                s3= pf.getText();
                s4= cb.getSelectedItem().toString();
                
                if(jc1.isSelected() && jc2.isSelected() && jc3.isSelected())
                {s5= jc1.getText()+','+" "+jc2.getText()+','+" "+jc3.getText();}
                else if(jc1.isSelected() && jc2.isSelected())
                {s5= jc1.getText()+','+" "+jc2.getText();}
                else if(jc2.isSelected() && jc3.isSelected())
                {s5= jc2.getText()+','+" "+jc3.getText();}
                else if(jc1.isSelected() && jc3.isSelected())
                {s5= jc1.getText()+','+" "+jc3.getText();}
                else if(jc1.isSelected())
                {s5= jc1.getText();}
                else if(jc2.isSelected())
                {s5= jc2.getText();}
                else if(jc3.isSelected())
                {s5= jc3.getText();}
                else 
                {s5= " ";}

                if(rb1.isSelected())
			    {
				s6 = rb1.getText();
			    }
			    else if(rb2.isSelected())
			    {
				s6 = rb2.getText();
			    }
                else if(rb3.isSelected())
                {
                s6 = rb3.getText();
                }
			    else 
			    {
				s6 = "Others";
			    }

                s7= ta.getText();

                if(s1.isEmpty() || s2.isEmpty() || s3.isEmpty() || s4.isEmpty() || s5.isEmpty() || s6.isEmpty() || s7.isEmpty())
                {
                    JOptionPane.showMessageDialog(this, "Please fill up all the informations");
                }
                else
                {
                    Customer c1 = new Customer(s1, s2, s3, s4, s5, s6, s7);
                    c1.insertInfo();
                    JOptionPane.showMessageDialog(this,"Thanks for filling up all the information");
                    showInfo();
                }
            }
		}
		public void mouseClicked(MouseEvent me)
		{
			if(me.getSource() == label5)
			{
				label5.setText("Extra items -");
			}
		}
		
		public void mousePressed(MouseEvent me)
		{
			if(me.getSource() == label2)
			{
				label2.setText("Customer Information");
			}
		}
		public void mouseReleased(MouseEvent me)
		{
			if(me.getSource() == label2)
			{
				label2.setText("Customer Info");
			}
		}
		public void mouseEntered(MouseEvent me)
		{
			if(me.getSource() == jb)
			{
				jb.setBackground(Color.BLACK);
				jb.setForeground(Color.WHITE);
			}
		}
		public void mouseExited(MouseEvent me)
		{
			if(me.getSource() == jb)
			{
				jb.setBackground(Color.GREEN);
				jb.setForeground(Color.BLACK);
			}
		}	
        
        public void showInfo()
        { 
            try
            {
                File file = new File("./Data/CustomerData.txt");
                if(file.exists())
                {
                    FileReader fr = new FileReader(file);
                    BufferedReader br = new BufferedReader(fr);

                    String line;
                    while((line = br.readLine()) != null)
                    {
                        model.addRow(new Object[]{line});
                    }
                    br.close();
                }
            }
            catch(IOException io)
        {
            io.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurs");
        }
        }
		
}

