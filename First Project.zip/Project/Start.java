import Frame.*; 
public class Start {
    public static void main (String[] args)
    {
        Project p1 = new Project();
        p1.setVisible(true);
    }
}
